from flask import Blueprint, render_template

user_controller = Blueprint('user_controller', __name__, url_prefix='/user', template_folder='views')

@user_controller.route('/login')
def user_login():
    return render_template('login.html')

