import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Question } from '../shared/question';

@Injectable({providedIn: 'root'})
export class MailService {
    constructor(private _http: HttpClient) { }

    url = 'http://3.82.155.203:3100/api/submit_disc_result/';
    
    postData(bodyJson: any) {
        return this._http.post(this.url, bodyJson);
    }
}