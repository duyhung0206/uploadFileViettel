export class Question {
    id: number;
    displayName: string;
    answer: string;
    mCheck: boolean;
    lCheck: boolean;
}