/**
 * @license
 * Copyright (c) 2018 amCharts (Antanas Marcelionis, Martynas Majeris)
 *
 * This sofware is provided under multiple licenses. Please see below for
 * links to appropriate usage.
 *
 * Free amCharts linkware license. Details and conditions:
 * https://github.com/amcharts/amcharts4/blob/master/LICENSE
 *
 * One of the amCharts commercial licenses. Details and pricing:
 * https://www.amcharts.com/online-store/
 * https://www.amcharts.com/online-store/licenses-explained/
 *
 * If in doubt, contact amCharts at contact@amcharts.com
 *
 * PLEASE DO NOT REMOVE THIS COPYRIGHT NOTICE.
 * @hidden
 */
am4internal_webpackJsonp(["8ce2"],{ik00:function(e,c,t){"use strict";Object.defineProperty(c,"__esModule",{value:!0});var b=t("Mtpk"),i=t("8ZqG"),n=function(e){Object(b.is)(e,"ColorSet")&&(e.list=[Object(i.c)("#bec4f8"),Object(i.c)("#a5abee"),Object(i.c)("#6a6dde"),Object(i.c)("#4d42cf"),Object(i.c)("#713e8d"),Object(i.c)("#a160a0"),Object(i.c)("#eb6eb0"),Object(i.c)("#f597bb"),Object(i.c)("#fbb8c9"),Object(i.c)("#f8d4d8")],e.minLightness=.2,e.maxLightness=.7,e.reuse=!0)};window.am4themes_frozen=n}},["ik00"]);
//# sourceMappingURL=frozen.js.map